<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href=""><i class="fa fa-instagram" style="font-size:36px"></i></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <a class="nav-link disabled" href="#" aria-disabled="true" color="red">Instagram</a>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0"></ul>
        <a class="nav-link" href="index.php"><button class="btn btn-success">Home</button></a>
        <a href="logout.php"><button class="btn btn-primary">Logout</button></a>
      </div>
    </div>
  </div>
</nav>

<div class="container">
<h1 align="center">Tambah</h1>
    <form action="proses_tambah.php" method="post" 
    enctype="multipart/form-data">
<form>
  <div class="mb-3">
    <label for="" class="form-label">Gambar</label>
    <input type="file" name="gambar" id="" class="form-control" required>
  </div>
  <div class="mb-3">
    <label for="" class="form-label">Caption</label>
    <input type="text" name="caption" id="" class="form-control" required>
  </div>
  <div class="mb-3">
    <label for="" class="form-label">Lokasi</label>
    <input type="text" name="lokasi" id="" class="form-control" required>
  </div>
  <button type="submit" value="Simpan" name="simpan" class="btn btn-primary">Simpan</button>
</form>

</body>
</html>