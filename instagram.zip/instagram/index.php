<?php 
session_start();
if (!isset($_SESSION['login'])) {
    header ("location:login.php?pesan=logindulu");
}

include "koneksi.php";
$sql = "SELECT * FROM post order by no desc";
$query = mysqli_query($koneksi,$sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="icon" href="logo.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <center>
      
    <style>
    .card-img-top {

transition: transform 0.3s; /* Animation */

}

.card-img-top:hover {
transform: scale(1.1); /* (150% zoom - Note: if the zoom is too large, it will go outside of the viewport) */
}

body {
  background: #B4B4B3;
  background-image: url('butterfly.png');
  background-position: absolute;
  background-size: 150px;
}

</style>
    <title>Story</title>
    <link rel="shortcut icon" href="logo.png" type="image/x-icon">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-light sticky-top">
  <div class="container-fluid">
    <img src="logo.png" width="50px" alt="">
    <a class="navbar-brand" href=""><i class="" style="font-size:36px"></i></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <a class="nav-link disabled" href="#" aria-disabled="true" style="color: #000;">Story All</a>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0"></ul>
        <a href="#" class="nav-link"><button type="submit" class="btn btn-outline-dark" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="fa fa-plus" style="font-size:20px"></i></button></a>
        <!-- <a class="nav-link" href="logout.php"><button class="btn btn-danger"><i class="fa fa-minus" ></button></a>
      </div> -->
      <a href="logout.php" class="btn btn-outline-danger"><i class="fa-solid fa-right-from-bracket"></i></i></a>
    </div>
  </div>
</nav>
<br>
    <div class="container">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <?php while ($post=mysqli_fetch_assoc($query)) { ?>
    <div class="card mb-3" style="width: 18rem;">
    <div class="zoom">
    <img class="card-img-top" src="images/<?= $post['gambar'] ?>" alt="Card image cap">
    <div class="card-body">
        <h5 class="caption"><?= $post['caption'] ?></h5>
        <p class="lokasi"><?= $post['lokasi'] ?></p>

    <a href="hapus.php?no=<?= $post['no'] ?>" class="btn btn-outline-danger"><i class="fa fa-trash" style="font-size:15px"></i></a>
    <button type="submit" class="btn btn-outline-dark" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $post['no'] ?>"><i class="fa fa-pencil"></i></button>

    <!-- modal edit -->
  <div class="modal fade" id="exampleModal<?= $post['no'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
  <div class="modal-content">
  <div class="modal-header">
  <h1 class="modal-title fs-5" id="exampleModalLabel">Edit</h1>
  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
  </div>

  <div class="modal-body">
  <form action="proses_edit.php" method="post" enctype="multipart/form-data">
  <input type="hidden" name="no" value="<?= $post['no'] ?>">
    <input type="hidden" name="foto_lama" value="<?= $post['gambar'] ?>">
    
        <label class="form-label" for="">Gambar</label>
        <input class="form-control" type="file" name="gambar" id="" value="<?= $post['gambar'] ?>" ><br>
        <img src="gambar/<?= $post['gambar'] ?>" width="200" alt="" ><br><br>

        <div class="col-auto">
        <label class="form-label" for="">Caption</label>
        </div>

        <input class="form-control" type="text" name="caption"value="<?= $post['caption'] ?>" id="" autocomplete="off"><br>

        <label class="form-label" for="">Lokasi</label>
        <input class="form-control" type="text" name="lokasi" value="<?= $post['lokasi'] ?>" id="" autocomplete="off"><br>


    <button type="submit" class="btn btn-dark" value="Update" name="update">Ubah</button>

    </form>
  </div>
  </div>
  </div>
</div>

  </div>
</div>
</div>
<?php } ?>
    
    </div>
    </center>

    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
  <div class="modal-content">
  <div class="modal-header">
  <h1 class="modal-title fs-5" id="exampleModalLabel">Tambah</h1>
  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
  </div>

  <div class="modal-body">
  <form action="proses_tambah.php" method="post"enctype="multipart/form-data">
  <label for="">Gambar</label>
  <input type="file" name="gambar" class="form-control" id="" required><br>

  <label for="">Caption</label>
  <input type="text" name="caption" class="form-control" id="" autocomplete="off"><br>

  <label for="">Lokasi</label>
  <input type="text" name="lokasi" class="form-control" id=""><br>

  <input type="submit" value="Simpan" name="simpan" class="btn btn-outline-dark">

  </form>
  </div>
  </div>
  </div>
</div>
</body><br><br>
</html>
